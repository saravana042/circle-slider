
	// Plugin call 
		
	$(document).ready(function () {
		 
		// TEMPRATURE SLIDER
		 
			$( "#slider-vertical" ).slider({
				orientation: "vertical",
				range: "min",
				min: 0,
				max: 34,
				value: 34,
				slide: function( event, ui ) {
					return false;
					$( "#showTempValue" ).html( ui.value );
				}
			});
		
			$( "#showTempValue, #tempValue" ).html( $( "#slider-vertical" ).slider( "value" ) );
			
		// TEMPRATURE PLUS BUTTON CALL
			
			$( "#plus" ).click( function(){
				if($( "#slider-vertical" ).slider( "value" ) < 34){
					$( "#showTempValue, #tempValue" ).html( $( "#slider-vertical" ).slider( "value" ) + 1 );
					$("#slider-vertical").slider('value',$( "#slider-vertical" ).slider( "value" ) + 1);
				}
			});
			
		// TEMPRATURE MINUS BUTTON CALL 
			
			$( "#minus" ).click( function(){
				if($( "#slider-vertical" ).slider( "value" ) > 16){
					$( "#showTempValue, #tempValue" ).html( $( "#slider-vertical" ).slider( "value" ) - 1 );
					$("#slider-vertical").slider('value',$( "#slider-vertical" ).slider( "value" ) - 1);
				}
			});

		// SELECT HOUR SLIDER 
		
            $("#selectHourSlider").roundSlider({
				value:22,
				min: 0,
				max: 24,
				width:30,
				startAngle: 90,
				handleShape: "dot",
                sliderType: "min-range",
				create: "traceEvent",
				start: "traceEvent",
				stop: "traceEvent",
				change: "traceEvent",
				drag: "traceEvent"
            });
			
		// SELECT HOUR SLIDER DROP DOWN CHANGE
		
			$('#selectHours').on('change', function()
			{
				var selectedHours = $("#selectHours option:selected").val();
				$("#selectHourSlider").roundSlider("option", "value", selectedHours);
				$('.rs-tooltip-text').html($("#selectHours option:selected").val()+'hrs'+'<span class="on-week">on weekdays</span>').css( {"margin-left":"-35px", "margin-top": "-24px"} );
				$('#selectHours option').removeAttr("selected");
				$('#selectHours option[value='+selectedHours+']').attr('selected','selected');
				$("#selectHours").val(selectedHours);
			});
			$('.rs-tooltip.rs-tooltip-text ').removeClass('edit'); 
			
		// TAB
		
			/* $('ul.tabs li').click(function(){
				var tab_id = $(this).attr('data-tab');

				$('ul.tabs li').removeClass('current');
				$('.tab-content').removeClass('current');

				$(this).addClass('current');
				$("#"+tab_id).addClass('current');
			}); */
			
		// SELECT DROP DOWN
		
			$('select').niceSelect();
			
			
			
		// CUSTOM TAB
		
			$(".tab_content").hide();
			$(".tab_content:first").show();

			/* if in tab mode */
			$("ul.tabs li").click(function() {

			$(".tab_content").hide();
			var activeTab = $(this).attr("rel"); 
			$("#"+activeTab).fadeIn();		

			$("ul.tabs li").removeClass("active");
			$(this).addClass("active");

			$(".tab_drawer_heading").removeClass("d_active");
			$(".tab_drawer_heading[rel^='"+activeTab+"']").addClass("d_active");

			});
			/* if in drawer mode */
			$(".tab_drawer_heading").click(function() {

			$(".tab_content").hide();
			var d_activeTab = $(this).attr("rel"); 
			$("#"+d_activeTab).fadeIn();

			$(".tab_drawer_heading").removeClass("d_active");
			$(this).addClass("d_active");

			$("ul.tabs li").removeClass("active");
			$("ul.tabs li[rel^='"+d_activeTab+"']").addClass("active");
			});

			$('ul.tabs li').last().addClass("tab_last");

		});
		
		function traceEvent(e) {
			$('.rs-tooltip-text').html( e.value +'hrs'+'<span class="on-week">on weekdays</span>' ).css( {"margin-left":"-35px", "margin-top": "-24px"} );
			$('#selectHours option').removeAttr("selected");
			$('#selectHours option[value='+e.value+']').attr('selected','selected');
			$("#selectHours").val(e.value);
			$('.nice-select .current').text(e.value);
		}
		